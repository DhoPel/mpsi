﻿Imports MySql.Data.MySqlClient

Module koneksi2
    Public dbconn2 As New MySqlConnection
    Public sql2 As String
    Public sqlcomm2 As MySqlCommand
    Public dbread2 As MySqlDataReader
    Public dset2 As DataSet
    Public level2 As String

    Public Sub konekdb2()
        'Local Database
        dbconn2 = New MySqlConnection("Data Source=localhost;user id=root; database=karyawan;")
        Try
            dbconn2.Open()
        Catch ex As Exception
            MsgBox("Error in connection, please check the database and connection server.", vbCritical, "System Demo Only")
            End
        End Try
    End Sub
    Public Sub closedb2()
        If dbconn2.State = ConnectionState.Open Then
            dbconn2.Close()
        End If
    End Sub




End Module