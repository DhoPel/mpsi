﻿Imports MySql.Data.MySqlClient

Module Koneksi
    Public dbconn As New MySqlConnection
    Public sql As String
    Public sqlcomm As MySqlCommand
    Public dbread As MySqlDataReader
    Public dset As DataSet
    Public level As String

    Public Sub konekdb()
        'Local Database
        dbconn = New MySqlConnection("Data Source=localhost;user id=root; database=indomaret;")
        Try
            dbconn.Open()
        Catch ex As Exception
            MsgBox("Error in connection, please check the database and connection server.", vbCritical, "System Demo Only")
            End
        End Try
    End Sub

    Public Sub closedb()
        If dbconn.State = ConnectionState.Open Then
            dbconn.Close()
        End If
    End Sub

End Module