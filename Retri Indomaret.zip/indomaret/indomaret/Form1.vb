﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Public da As MySqlDataAdapter
    Public ds As DataSet
    Dim sql As String
    Dim konfirmasi As String
    Sub tampil()
        Call konekdb()
        da = New MySqlDataAdapter("select * from indomaret order by kode_barang", dbconn)
        ds = New DataSet
        da.Fill(ds, "indomaret")
        DataGridView1.DataSource = ds.Tables("indomaret")
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call tampil()
        Call setting_header()
    End Sub
    Sub setting_header()
        Try
            DataGridView1.Columns(0).Width = 200
            DataGridView1.Columns(1).Width = 150
            DataGridView1.Columns(2).Width = 100
            DataGridView1.Columns(3).Width = 100
            DataGridView1.Columns(0).HeaderText = "nama barang"
            DataGridView1.Columns(1).HeaderText = "kode barang"
            DataGridView1.Columns(2).HeaderText = "harga barang"
            DataGridView1.Columns(3).HeaderText = "stok barang"
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Call konekdb()
        Try
            sql = "insert into indomaret values ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "')"
            sqlcomm = New MySqlCommand(sql, dbconn)
            sqlcomm.ExecuteNonQuery()
            MsgBox("Data barang Berhasil di Simpan")
            Call tampil()
        Catch ex As Exception
            MsgBox("Data barang Gagal di Simpan")
        End Try
        Call closedb()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Call konekdb()
        sql = "SELECT * FROM indomaret WHERE nama_barang = '" & TextBox1.Text & "'"
        sqlcomm = New MySqlCommand(sql, dbconn)
        dbread = sqlcomm.ExecuteReader()
        dbread.Read()
        If dbread.HasRows Then
            MsgBox("Data sudah ada")
            TextBox1.Text = dbread.Item("nama_barang")
            TextBox2.Text = dbread.Item("kode_barang")
            TextBox3.Text = dbread.Item("harga_barang")
            TextBox4.Text = dbread.Item("stok_barang")
            closedb()

        Else
            MsgBox("Data tidak ada")
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Call konekdb()
        sql = "update indomaret set nama_barang='" & TextBox1.Text & "', kode_barang='" & TextBox2.Text & "', harga_barang='" & TextBox3.Text & "', stok_barang='" & TextBox4.Text & "' where kode_barang = '" & TextBox2.Text & "'"
        sqlcomm = New MySqlCommand(sql, dbconn)
        sqlcomm.ExecuteNonQuery()
        MsgBox("Data Berhasil di Ubah")
        Call tampil()
        Call closedb()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If TextBox1.Text = "" Then
            MsgBox("Silahkan Pilih Data yang akan di hapus dengan Masukan kode_barang dan ENTER")
            TextBox1.Focus()
        Else
            If MessageBox.Show("Yakin akan dihapus..?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call konekdb()
                sql = "delete From indomaret  where kode_barang='" & TextBox2.Text & "'"
                sqlcomm = New MySqlCommand(sql, dbconn)
                sqlcomm.ExecuteNonQuery()
                Call tampil()

            End If
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        konfirmasi = MsgBox("anda yakin ingin keluar?", vbQuestion + vbYesNo, "konfirmasi")
        If konfirmasi = vbYes Then
            Close()
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Form4.Show()
        Me.Close()

    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox1.Select()

    End Sub
End Class
