﻿Public Class Form5
    Dim konfirmasi As Integer

    Private Sub Btnlogin_Click(sender As Object, e As EventArgs) Handles Btnlogin.Click
        If Txtusername.Text = "" And Txtpasword.Text = "" Then
            MsgBox("username dan pasword tidak boleh kosong", MsgBoxStyle.Exclamation, "isi username dan pasword")
        ElseIf Txtusername.Text = "indomaret" And Txtpasword.Text = "123456" Then
            MsgBox("login berhasil", MsgBoxStyle.Exclamation, "Akses Berhasil")
            Form4.Show()
            Me.Hide()
        Else
            MsgBox("Kombinasi username dan pasword salah!", MsgBoxStyle.Critical, "Cek username dan pasword")
            Call bersih()
            Txtusername.Focus()
        End If
    End Sub
    Sub bersih()
        Txtusername.Text = ""
        Txtpasword.Text = ""
    End Sub

    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Txtusername.Focus()
        Txtpasword.UseSystemPasswordChar = True
        Label8.Text = Today

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            Txtpasword.UseSystemPasswordChar = False
        Else
            Txtpasword.UseSystemPasswordChar = True
        End If
        Txtpasword.Focus()
    End Sub

    Private Sub Btncancel_Click(sender As Object, e As EventArgs) Handles Btncancel.Click
        konfirmasi = MsgBox("anda yakin ingin keluar?", vbQuestion + vbYesNo, "konfirmasi")
        If konfirmasi = vbYes Then
            Close()


        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs)
       
    End Sub

    Private Sub Timer1_Tick_1(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label9.Text = TimeOfDay
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub
End Class