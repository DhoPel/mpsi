﻿Imports MySql.Data.MySqlClient
Public Class Form3
    Public da As MySqlDataAdapter
    Public ds As DataSet
    Dim sql As String
    Dim konfirmasi As String
    Sub tampil()
        Call konekdb2()
        da = New MySqlDataAdapter("select * from karyawan order by no_identitas", dbconn2)
        ds = New DataSet
        da.Fill(ds, "karyawan")
        DataGridView1.DataSource = ds.Tables("karyawan")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Call konekdb2()
        Try
            sql = "insert into karyawan values ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "')"
            sqlcomm2 = New MySqlCommand(sql, dbconn2)
            sqlcomm2.ExecuteNonQuery()
            MsgBox("Data karyawan Berhasil di Simpan")
            Call tampil()
        Catch ex As Exception
            MsgBox("Data karyawan Gagal di Simpan")
        End Try
        Call closedb2()
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call tampil()
        Call setting_header()
    End Sub
    Sub setting_header()
        Try
            DataGridView1.Columns(0).Width = 200
            DataGridView1.Columns(1).Width = 150
            DataGridView1.Columns(2).Width = 120
            DataGridView1.Columns(3).Width = 100
            DataGridView1.Columns(4).Width = 100
            DataGridView1.Columns(0).HeaderText = "NAMA"
            DataGridView1.Columns(1).HeaderText = "NO. IDENTITAS"
            DataGridView1.Columns(2).HeaderText = "JENIS KELAMIN"
            DataGridView1.Columns(3).HeaderText = "JAM KERJA"
            DataGridView1.Columns(4).HeaderText = "JABATAN"
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Call konekdb2()
        sql = "update karyawan set nama='" & TextBox1.Text & "', no_identitas='" & TextBox2.Text & "', jenis_kelamin='" & TextBox3.Text & "', jam_kerja='" & TextBox4.Text & " ', jabatan= '" & TextBox5.Text & "' where no_identitas='" & TextBox2.Text & "'"
        sqlcomm2 = New MySqlCommand(sql, dbconn2)
        sqlcomm2.ExecuteNonQuery()
        MsgBox("Data Berhasil di Ubah")
        Call tampil()
        Call closedb2()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If TextBox1.Text = "" Then
            MsgBox("Silahkan Pilih Data yang akan di hapus dengan Masukan no_identitas dan ENTER")
            TextBox1.Focus()
        Else
            If MessageBox.Show("Yakin akan dihapus..?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call konekdb2()
                sql = "delete From karyawan where no_identitas='" & TextBox2.Text & "'"
                sqlcomm2 = New MySqlCommand(sql, dbconn2)
                sqlcomm2.ExecuteNonQuery()
                Call tampil()

            End If
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Call konekdb2()
        sql = "SELECT * FROM karyawan WHERE nama = '" & TextBox1.Text & "'"
        sqlcomm2 = New MySqlCommand(sql, dbconn2)
        dbread2 = sqlcomm2.ExecuteReader()
        dbread2.Read()
        If dbread2.HasRows Then
            MsgBox("Data sudah ada")
            TextBox1.Text = dbread2.Item("nama")
            TextBox2.Text = dbread2.Item("no_identitas")
            TextBox3.Text = dbread2.Item("jenis_kelamin")
            TextBox4.Text = dbread2.Item("jam_kerja")
            TextBox5.Text = dbread2.Item("jabatan")
            closedb2()

        Else
            MsgBox("Data tidak ada")
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        konfirmasi = MsgBox("anda yakin ingin keluar?", vbQuestion + vbYesNo, "konfirmasi")
        If konfirmasi = vbYes Then
            Close()
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Form4.Show()
        Me.Close()

    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox1.Select()

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class